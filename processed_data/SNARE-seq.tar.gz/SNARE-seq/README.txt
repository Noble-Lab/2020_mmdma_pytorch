#This folder contains the processed datasets for SNARE-seq data (for details please refer to the manuscript)
*_feat.npy: Files containing the processed features
*_matrix.npy: Files containing the input kernel matrices for MMD-MA algorithm

#note: The sample have one to one correspondeces, there for sample at row index 1 in sciATAC corresponds to sample at row index 1 in sciRNA
